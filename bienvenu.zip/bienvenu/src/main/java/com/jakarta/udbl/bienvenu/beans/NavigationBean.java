/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.jakarta.udbl.bienvenu.beans;
import com.jakarta.udbl.bienvenu.business.LieuEntrepriseBean; // Import de la façade
import com.jakarta.udbl.bienvenu.entities.Lieu;       // Import de l'entité
import jakarta.enterprise.context.RequestScoped;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.io.IOException;

@Named(value = "navigationController")
@RequestScoped
public class NavigationBean {

    @Inject
    private LieuEntrepriseBean lieuFacade; // On injecte l'EJB pour parler à la base

    private Lieu nouveauLieu = new Lieu(); // L'objet qui recevra les saisies

    // Méthode pour le bouton "Enregistrer" du formulaire lieu.xhtml
    public void enregistrer() {
        try {
            lieuFacade.creerLieu(nouveauLieu); // On sauvegarde dans Derby !
            FacesContext.getCurrentInstance().getExternalContext().redirect("home.xhtml");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Indispensable pour que le XHTML puisse remplir l'objet
    public Lieu getNouveauLieu() {
        return nouveauLieu;
    }

    // Tes méthodes de redirection existantes restent ici (ajouter, visiter, apropos...)
    public void ajouter() {
        try {
            FacesContext.getCurrentInstance().getExternalContext().redirect("lieu.xhtml");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void home() {
        try {
            // On force la redirection vers la page physique [cite: 293, 294]
            FacesContext.getCurrentInstance().getExternalContext().redirect("home.xhtml");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void apropos() {
        try {
            // On force la redirection vers la page physique [cite: 293, 294]
            FacesContext.getCurrentInstance().getExternalContext().redirect("a_propos.xhtml");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
   
    public void visiter() 
    {
        try {
            // On force la redirection vers la page physique [cite: 293, 294]
            FacesContext.getCurrentInstance().getExternalContext().redirect("visiter.xhtml");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}