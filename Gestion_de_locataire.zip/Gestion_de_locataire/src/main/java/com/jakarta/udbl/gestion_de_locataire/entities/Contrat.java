/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.jakarta.udbl.gestion_de_locataire.entities;

/**
 *
 * @author HP
 */

import java.io.Serializable;
import java.util.Date;

public class Contrat implements Serializable {
    private String nomContracteur;
    private String appartementAlloue;
    private Date dateEntree;
    private Date dateExpiration;

    public Contrat() {}

    // Getters et Setters
    public String getNomContracteur() { return nomContracteur; }
    public void setNomContracteur(String nomContracteur) { this.nomContracteur = nomContracteur; }

    public String getAppartementAlloue() { return appartementAlloue; }
    public void setAppartementAlloue(String appartementAlloue) { this.appartementAlloue = appartementAlloue; }

    public Date getDateEntree() { return dateEntree; }
    public void setDateEntree(Date dateEntree) { this.dateEntree = dateEntree; }

    public Date getDateExpiration() { return dateExpiration; }
    public void setDateExpiration(Date dateExpiration) { this.dateExpiration = dateExpiration; }
}