package com.jakarta.udbl.gestion_de_locataire.beans;

import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;
import java.io.IOException;
import java.io.Serializable;

@Named(value = "nav")
@SessionScoped
public class NavigationBean implements Serializable {
    
    // "TABLEAU" est la vue par défaut (Locataires existants)
    private String currentView = "TABLEAU"; 

    public String getCurrentView() {
        return currentView;
    }

    public void setCurrentView(String view) {
        this.currentView = view;
    }

    // Titre dynamique pour la zone de droite
    public String getViewTitle() {
        switch (currentView) {
            case "AJOUTER": return "Ajout de locataire";
            case "MODIFIER": return "Modification de locataire";
            case "SUPPRIMER": return "Suppression de locataire";
            case "SUIVI": return "Suivit de contrat";
            case "DEMANDES": return "Gestion de demandes";
            default: return "Locataires existants";
        }
    }
  public void menu() {
        try {
            // On force la redirection vers la page physique [cite: 293, 294]
            FacesContext.getCurrentInstance().getExternalContext().redirect("pages/gestion_locataire.xhtml");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}