/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.jakarta.udbl.gestion_de_locataire.entities;

/**
 *
 * @author HP
 */


import java.io.Serializable;
import java.util.Date;

/**
 * Entité représentant un Locataire
 * Implémente Serializable pour être utilisé dans un SessionScoped Bean
 */
public class Locataire implements Serializable {
    
    private int id;
    private String nom;
    private String contact;
    private String appartement;
    private Date dateEntree;
    
    // Objets liés selon ton DSL
    private Demande demande;
    private Contrat contrat;

    // Constructeur par défaut (Obligatoire pour JSF/JavaBeans)
    public Locataire() {
    }

    // Getters et Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getAppartement() {
        return appartement;
    }

    public void setAppartement(String appartement) {
        this.appartement = appartement;
    }

    public Date getDateEntree() {
        return dateEntree;
    }

    public void setDateEntree(Date dateEntree) {
        this.dateEntree = dateEntree;
    }

    public Demande getDemande() {
        return demande;
    }

    public void setDemande(Demande demande) {
        this.demande = demande;
    }

    public Contrat getContrat() {
        return contrat;
    }

    public void setContrat(Contrat contrat) {
        this.contrat = contrat;
    }
}