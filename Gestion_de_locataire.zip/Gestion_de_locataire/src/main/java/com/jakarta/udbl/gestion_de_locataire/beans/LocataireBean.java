/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.jakarta.udbl.gestion_de_locataire.beans;

/**
 *
 * @author HP
 */


import com.jakarta.udbl.gestion_de_locataire.dao.LocataireDAO;
import com.jakarta.udbl.gestion_de_locataire.entities.Locataire;
import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import java.io.Serializable;
import java.util.List;

@Named("locataireBean")
@SessionScoped
public class LocataireBean implements Serializable {

    // Objets de données
    private Locataire nouveauLocataire = new Locataire();
    private List<Locataire> listeLocataires;
    
    // Instance du DAO pour la communication DB
    private LocataireDAO dao = new LocataireDAO();

    /**
     * Cette méthode s'exécute automatiquement dès que le Bean est créé.
     * C'est le moment idéal pour charger la liste depuis la base de données.
     */
    @PostConstruct
    public void init() {
        chargerLocataires();
    }

    // Méthode pour récupérer la liste mise à jour depuis le DAO
    public void chargerLocataires() {
        this.listeLocataires = dao.findAll();
    }

    /**
     * Action appelée par le bouton "Ajouter" de ton interface.
     */
    public void ajouter() {
        // 1. Demander au DAO de sauvegarder l'objet rempli par le formulaire
        dao.save(nouveauLocataire);
        
        // 2. Réinitialiser l'objet pour vider les champs du formulaire à l'écran
        nouveauLocataire = new Locataire();
        
        // 3. Recharger la liste pour que le tableau affiche le nouveau locataire
        chargerLocataires();
        
        System.out.println("LOG: Un nouveau locataire a été ajouté en base de données.");
    }

    // --- GETTERS ET SETTERS (Indispensables pour JSF) ---

    public Locataire getNouveauLocataire() {
        return nouveauLocataire;
    }

    public void setNouveauLocataire(Locataire nouveauLocataire) {
        this.nouveauLocataire = nouveauLocataire;
    }

    public List<Locataire> getListeLocataires() {
        return listeLocataires;
    }

    public void setListeLocataires(List<Locataire> listeLocataires) {
        this.listeLocataires = listeLocataires;
    }
}