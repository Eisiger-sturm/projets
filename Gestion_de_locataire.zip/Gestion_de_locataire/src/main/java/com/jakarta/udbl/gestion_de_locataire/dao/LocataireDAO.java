/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.jakarta.udbl.gestion_de_locataire.dao;

/**
 *
 * @author HP
 */


import com.jakarta.udbl.gestion_de_locataire.entities.Locataire;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LocataireDAO {
    
    // L'URL de ta base créée avec ij
    private final String URL = "jdbc:derby:ImmoDB";
    
    // Méthode utilitaire pour obtenir la connexion
    private Connection getConnection() throws SQLException {
        // En mode atelier (Embedded), le driver est chargé automatiquement
        return DriverManager.getConnection(URL);
    }
    public List<Locataire> findAll() {
        List<Locataire> locataires = new ArrayList<>();
        String sql = "SELECT * FROM LOCATAIRE";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Locataire l = new Locataire();
                l.setId(rs.getInt("id"));
                l.setNom(rs.getString("nom"));
                l.setContact(rs.getString("contact"));
                l.setAppartement(rs.getString("appartement"));
                // On récupère la date si elle n'est pas nulle
                if (rs.getDate("date_entree") != null) {
                    l.setDateEntree(new java.util.Date(rs.getDate("date_entree").getTime()));
                }
                locataires.add(l);
            }
        } catch (SQLException e) {
            System.err.println("Erreur findAll : " + e.getMessage());
        }
        return locataires;
    }
    public void save(Locataire l) {
        String sql = "INSERT INTO LOCATAIRE (nom, contact, appartement, date_entree) VALUES (?, ?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, l.getNom());
            ps.setString(2, l.getContact());
            ps.setString(3, l.getAppartement());
            
            if (l.getDateEntree() != null) {
                ps.setDate(4, new java.sql.Date(l.getDateEntree().getTime()));
            } else {
                ps.setNull(4, Types.DATE);
            }

            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Erreur save : " + e.getMessage());
        }
    }
}
    