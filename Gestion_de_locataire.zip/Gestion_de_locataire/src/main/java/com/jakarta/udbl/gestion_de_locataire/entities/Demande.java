/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.jakarta.udbl.gestion_de_locataire.entities;

/**
 *
 * @author HP
 */


import java.io.Serializable;
import java.util.Date;

public class Demande implements Serializable {
    // Enumération pour le statut
    public enum Statut { repondu, enAttente }

    private String nomRedacteur;
    private String appartementConcerne;
    private String motif;
    private Date dateSoumission;
    private Statut statut = Statut.enAttente; // Par défaut

    public Demande() {}

    // Getters et Setters
    public String getNomRedacteur() { return nomRedacteur; }
    public void setNomRedacteur(String nomRedacteur) { this.nomRedacteur = nomRedacteur; }

    public String getAppartementConcerne() { return appartementConcerne; }
    public void setAppartementConcerne(String appartementConcerne) { this.appartementConcerne = appartementConcerne; }

    public String getMotif() { return motif; }
    public void setMotif(String motif) { this.motif = motif; }

    public Date getDateSoumission() { return dateSoumission; }
    public void setDateSoumission(Date dateSoumission) { this.dateSoumission = dateSoumission; }

    public Statut getStatut() { return statut; }
    public void setStatut(Statut statut) { this.statut = statut; }
}