package com.jakarta.udbl.bienvenu.business;

import com.jakarta.udbl.bienvenu.entities.Utilisateur;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import org.mindrot.jbcrypt.BCrypt; // Importation de la bibliothèque de hachage
import java.util.List;

@Stateless
public class UtilisateurEntrepriseBean {

    @PersistenceContext
    private EntityManager em;

    @Transactional
    public void ajouterUtilisateurEntreprise(String username, String email, String password, String description) {
        // Hachage du mot de passe avant l'insertion
        String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt());
        Utilisateur utilisateur = new Utilisateur(username, email, hashedPassword, description);
        em.persist(utilisateur);
    }

    // Résolution du TP : Vérifier si l'utilisateur existe déjà
    public boolean existeDeja(String username, String email) {
        Long count = (Long) em.createQuery("SELECT COUNT(u) FROM Utilisateur u WHERE u.username = :u OR u.email = :e")
                .setParameter("u", username)
                .setParameter("e", email)
                .getSingleResult();
        return count > 0;
    }

    public boolean verifierMotDePasse(String password, String hashedPassword) {
        return BCrypt.checkpw(password, hashedPassword);
    }
    public Utilisateur authentifier(String email, String password) {
    // On récupère l'utilisateur par son email
    Utilisateur user = trouverUtilisateurParEmail(email);
    
    // On compare le mot de passe saisi avec celui haché en base (BCrypt)
    if (user != null && org.mindrot.jbcrypt.BCrypt.checkpw(password, user.getPassword())) {
        return user;
    }
    return null;
}

  public Utilisateur trouverUtilisateurParEmail(String email) {
    try {
        // On cherche l'utilisateur dont l'email correspond au paramètre
        return em.createQuery("SELECT u FROM Utilisateur u WHERE u.email = :email", Utilisateur.class)
                .setParameter("email", email)
                .getSingleResult();
    } catch (Exception e) {
        // Si aucun utilisateur n'est trouvé, on retourne null au lieu de faire crasher l'appli
        return null;
    }
}


// ... reste de la classe

@Transactional // Obligatoire pour modifier la base de données
public void mettreAJourMotDePasse(String email, String nouveauPassword) {
    try {
        // 1. On recherche l'utilisateur en base par son email unique
        Utilisateur user = trouverUtilisateurParEmail(email);
        
        if (user != null) {
            // 2. On hache le nouveau mot de passe (Sécurité)
            String hashedPassword = BCrypt.hashpw(nouveauPassword, BCrypt.gensalt());
            
            // 3. On met à jour l'objet avec le nouveau mot de passe haché
            user.setPassword(hashedPassword);
            
            // 4. On synchronise avec la base de données
            em.merge(user); 
            
            System.out.println("Succès : Mot de passe mis à jour pour " + email);
        }
    } catch (Exception e) {
        System.out.println("Erreur lors de la mise à jour : " + e.getMessage());
        e.printStackTrace();
    }
}
}