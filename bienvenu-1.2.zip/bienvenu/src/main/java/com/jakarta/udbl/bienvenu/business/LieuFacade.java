/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.jakarta.udbl.bienvenu.business;


import com.jakarta.udbl.bienvenu.entities.Lieu;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@Stateless // Dit à GlassFish que c'est un composant métier
public class LieuFacade {

    @PersistenceContext(unitName = "indonesiaPU") // Lien avec le persistence.xml
    private EntityManager em;

    public void creerLieu(Lieu lieu) {
        em.persist(lieu); // La commande magique qui enregistre en base !
    }
}