package com.jakarta.udbl.bienvenu.beans;

import com.jakarta.udbl.bienvenu.business.UtilisateurEntrepriseBean;
import com.jakarta.udbl.bienvenu.business.SessionManager;
import com.jakarta.udbl.bienvenu.entities.Utilisateur;
import jakarta.enterprise.context.RequestScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.io.Serializable;

@Named(value = "welcomeBean")
@RequestScoped
public class WelcomeBean implements Serializable {

    private String email;
    private String password;
    private String nouveauPassword;

    @Inject
    private UtilisateurEntrepriseBean utilisateurEntrepriseBean;

    @Inject
    private SessionManager sessionManager;

    public String sAuthentifier() {
        FacesContext context = FacesContext.getCurrentInstance();
        Utilisateur utilisateur = utilisateurEntrepriseBean.authentifier(email, password);

        if (utilisateur != null) {
            sessionManager.createSession("userEmail", utilisateur.getEmail());
            return "home?faces-redirect=true";
        } else {
            context.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, 
                "Email ou mot de passe incorrect.", null));
            return null;
        }
    }

   // Pour afficher l'email en lecture seule
public String getEmail() {
    if (email == null) email = sessionManager.getValueFromSession("userEmail");
    return email;
}

// Pour déconnecter l'utilisateur
public String deconnecter() {
    sessionManager.invalidateSession();
    return "/index?faces-redirect=true";
}

// Pour enregistrer le nouveau mot de passe
public void modifierProfil() {
    String emailSession = sessionManager.getValueFromSession("userEmail");
    if (nouveauPassword != null && !nouveauPassword.isEmpty()) {
        utilisateurEntrepriseBean.mettreAJourMotDePasse(emailSession, nouveauPassword);
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Succès : Mot de passe modifié !"));
    }
}
    public void setEmail(String email) { this.email = email; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getNouveauPassword() { return nouveauPassword; }
    public void setNouveauPassword(String np) { this.nouveauPassword = np; }
}