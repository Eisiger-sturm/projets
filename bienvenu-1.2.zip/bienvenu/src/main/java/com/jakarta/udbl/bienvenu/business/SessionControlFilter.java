package com.jakarta.udbl.bienvenu.business;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebFilter("/pages/*")
public class SessionControlFilter implements Filter {
   
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {}

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        // On vérifie la session avec la clé utilisée dans WelcomeBean
        String email = (String) httpRequest.getSession().getAttribute("userEmail");
       
        if (email == null) {
            // Pas de session ? Redirection vers la page de connexion
            httpResponse.sendRedirect(httpRequest.getContextPath() + "/index.xhtml");
        } else {
            // Connecté ? On laisse passer
            chain.doFilter(request, response);
        }
    }

    @Override
    public void destroy() {}
}