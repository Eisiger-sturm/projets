package com.jakarta.udbl.bienvenu.beans;

import com.jakarta.udbl.bienvenu.business.LieuEntrepriseBean;
import com.jakarta.udbl.bienvenu.entities.Lieu;
import jakarta.enterprise.context.SessionScoped; // SessionScoped pour garder le lieu à modifier
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.io.Serializable;
import java.util.List;

@Named(value = "lieuBean")
@SessionScoped // Changé en Session pour la modification
public class LieuBean implements Serializable {

    @Inject
    private LieuEntrepriseBean lieuEntrepriseBean;

    private Lieu lieuSelectionne = new Lieu(); // Utilise l'objet directement

    // Actions
    public String ajouterLieu() {
        lieuEntrepriseBean.ajouterLieuEntreprise(lieuSelectionne.getNom(), lieuSelectionne.getDescription(), lieuSelectionne.getLatitude(), lieuSelectionne.getLongitude());
        lieuSelectionne = new Lieu(); // Reset
        return "home?faces-redirect=true";
    }

    public String supprimer(Lieu l) {
        lieuEntrepriseBean.supprimer(l);
        return "home?faces-redirect=true";
    }

    public String preparerModifier(Lieu l) {
        this.lieuSelectionne = l;
        return "modifierLieu"; // Vers une nouvelle page modifierLieu.xhtml
    }

    public String mettreAJour() {
        lieuEntrepriseBean.modifier(this.lieuSelectionne);
        lieuSelectionne = new Lieu();
        return "home?faces-redirect=true";
    }

    public List<Lieu> getLieux() {
        return lieuEntrepriseBean.listerTousLesLieux();
    }

    public Lieu getLieuSelectionne() { return lieuSelectionne; }
    public void setLieuSelectionne(Lieu l) { this.lieuSelectionne = l; }
}