package com.jakarta.udbl.bienvenu.business;

import com.jakarta.udbl.bienvenu.entities.Lieu;
import com.jakarta.udbl.bienvenu.entities.Utilisateur;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.util.List;

@Stateless
public class LieuEntrepriseBean {

    @PersistenceContext(unitName = "indonesiaPU")
    private EntityManager em;

    public void ajouterLieuEntreprise(String nom, String desc, double lat, double lon) {
        Lieu n = new Lieu(nom, desc, lat, lon);
        em.persist(n);
    }

    public List<Lieu> listerTousLesLieux() {
        return em.createQuery("SELECT l FROM Lieu l", Lieu.class).getResultList();
    }

    public void supprimer(Lieu lieu) {
        // merge assure que l'objet est rattaché à la session avant suppression
        em.remove(em.merge(lieu));
    }

    public void modifier(Lieu lieu) {
        em.merge(lieu);
    }

    public void creerLieu(Lieu nouveauLieu) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    public void creerCompte(String username, String email, String password, String desc) {
    Utilisateur u = new Utilisateur();
    u.setUsername(username);
    u.setEmail(email);
    u.setPassword(password); // On le garde en clair pour l'instant comme demandé au début de l'atelier
    u.setDescription(desc);
    em.persist(u);
}
}