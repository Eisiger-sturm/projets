package com.jakarta.udbl.business;

import com.jakarta.udbl.bienvenu.entities.Utilisateur;
import jakarta.ejb.Stateless;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import org.mindrot.jbcrypt.BCrypt; // Importation de la bibliothèque de hachage
import java.util.List;

@Stateless
public class UtilisateurEntrepriseBean {

    @PersistenceContext
    private EntityManager em;

    @Transactional
    public void ajouterUtilisateurEntreprise(String username, String email, String password, String description) {
        // Hachage du mot de passe avant l'insertion
        String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt());
        Utilisateur utilisateur = new Utilisateur(username, email, hashedPassword, description);
        em.persist(utilisateur);
    }

    // Résolution du TP : Vérifier si l'utilisateur existe déjà
    public boolean existeDeja(String username, String email) {
        Long count = (Long) em.createQuery("SELECT COUNT(u) FROM Utilisateur u WHERE u.username = :u OR u.email = :e")
                .setParameter("u", username)
                .setParameter("e", email)
                .getSingleResult();
        return count > 0;
    }

    public boolean verifierMotDePasse(String password, String hashedPassword) {
        return BCrypt.checkpw(password, hashedPassword);
    }
}